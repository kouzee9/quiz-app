package com.quizapp.repo;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.quizapp.model.Question;

public class QuestionRepository {
	private static final String FILEPATH = "C:\\Users\\zisha\\Documents";
	private static final String FILE_NAME = "quiz-app-question-answer-bank.txt";
	private static final File file = new File(FILEPATH + "\\" + FILE_NAME);
	// private final BufferedWriter writer;
	
	public QuestionRepository()throws FileNotFoundException, IOException {
		createFile();
	}
	
	public List<String[]> retrieveQuestions(Question.Categories category) throws IOException {
		List<String[]> questions = new ArrayList<String[]>();
		try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
			String line;
			while ((line = reader.readLine())!= null) {
				switch (category.toString()) {
					case "MATHEMATICS":
						if (line.equals(Question.Categories.MATHEMATICS.toString().trim())) {
							line = reader.readLine();
							for (int i = 0; i <= 5; i++ ) {
								if (line.equals("")) 
									line = reader.readLine();
								if (line.equals(Question.Categories.MATHEMATICS.toString().trim() 
										+ " ANSWERS")) {
									break;
								} else {
									String[] question = new String[5];
									for (int j = 0; j <= 4; j++ ) {
										question[j] = line;
										// System.out.println(question[j]);
										line = reader.readLine();
									}
									questions.add(question);
								}
							}
						}
					break;
					case "HISTORY":
						if (line.equals(Question.Categories.HISTORY.toString().trim())) {
							line = reader.readLine();
							for (int i = 0; i <= 5; i++ ) {
								if (line.equals("")) 
									line = reader.readLine();
								if (line.equals(Question.Categories.HISTORY.toString().trim() 
										+ " ANSWERS")) {
									break;
								} else {
									String[] question = new String[5];
									for (int j = 0; j <= 4; j++ ) {
										question[j] = line;
										// System.out.println(question[j]);
										line = reader.readLine();
									}
									questions.add(question);
								}
							}
						}
					break;
					case "GEOGRAPHY":
						if (line.equals(Question.Categories.GEOGRAPHY.toString().trim())) {
							line = reader.readLine();
							for (int i = 0; i <= 5; i++ ) {
								if (line.equals("")) 
									line = reader.readLine();
								if (line.equals(Question.Categories.GEOGRAPHY.toString().trim() 
										+ " ANSWERS")) {
									break;
								} else {
									String[] question = new String[5];
									for (int j = 0; j <= 4; j++ ) {
										question[j] = line;
										// System.out.println(question[j]);
										line = reader.readLine();
									}
									questions.add(question);
								}
							}
						}
					break;
					case "SPORTS":
						if (line.equals(Question.Categories.SPORTS.toString().trim())) {
							line = reader.readLine();
							for (int i = 0; i <= 5; i++ ) {
								if (line.equals("")) 
									line = reader.readLine();
								if (line.equals(Question.Categories.SPORTS.toString().trim() 
										+ " ANSWERS")) {
									break;
								} else {
									String[] question = new String[5];
									for (int j = 0; j <= 4; j++ ) {
										question[j] = line;
										// System.out.println(question[j]);
										line = reader.readLine();
									}
									questions.add(question);
								}
							}
						}
					break;
				}
			}
		}
		return questions;
	}
	
	public EnumMap<Question.Categories, Map<String, String>> retrieveAnswers(Question.Categories category) 
			throws IOException {
		EnumMap<Question.Categories, Map<String, String>> answers = new EnumMap<>(Question.Categories.class); // look more into this
		Map<String, String> innerMap = new HashMap<>();
		try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
			String line;
			while ((line = reader.readLine()) != null) {
				switch (category.toString()) {
					case "MATHEMATICS":
						if (line.equals(Question.Categories.MATHEMATICS.toString().trim()
								+ " ANSWERS")) {
							while ((line = reader.readLine()) != null) {
								if (line.equals("END")) 
									break;
								innerMap.put(line.substring(0,1), line.substring(line.length() - 1, line.length()));
							}
						} else {
							// do nothing
						}
					answers.put(Question.Categories.MATHEMATICS, innerMap);
					break;
					case "HISTORY":
						if (line.equals(Question.Categories.HISTORY.toString().trim()
								+ " ANSWERS")) {
							System.out.println(line);
							while ((line = reader.readLine()) != null) {
								if (line.equals("END")) 
									break;
								innerMap.put(line.substring(0,1), line.substring(line.length() - 1, line.length()));
							}
						} else {
							// do nothing
						}
					answers.put(Question.Categories.HISTORY, innerMap);
					break;
					case "GEOGRAPHY":
						if (line.equals(Question.Categories.GEOGRAPHY.toString().trim()
								+ " ANSWERS")) {
							while ((line = reader.readLine()) != null) {
								if (line.equals("END")) 
									break;
								innerMap.put(line.substring(0,1), line.substring(line.length() - 1, line.length()));
							}
						} else {
							// do nothing
						}
					answers.put(Question.Categories.GEOGRAPHY, innerMap);
					break;
					case "SPORTS":
						if (line.equals(Question.Categories.SPORTS.toString().trim()
								+ " ANSWERS")) {
							while ((line = reader.readLine()) != null) {
								if (line.equals("END")) 
									break;
								innerMap.put(line.substring(0,1), line.substring(line.length() - 1, line.length()));
							}
						} else {
							// do nothing
						}
					answers.put(Question.Categories.SPORTS, innerMap);
					break;
				}
			}
		}
		// answers.put(Question.Categories.MATHEMATICS, innerMap);
		return answers;
	}
	
	private void createFile() {
		try {
			if (!file.exists()) {
				file.createNewFile();
				System.out.println("New File created");
			} else {
				return;
			}
		} catch (IOException io) {
			io.printStackTrace();
		}

	}
}
