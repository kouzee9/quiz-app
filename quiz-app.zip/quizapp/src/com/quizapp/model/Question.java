package com.quizapp.model;

import java.text.SimpleDateFormat;

public class Question {
	private int id;
	private String name;
	private String category;
	private String addedBy; 
	private SimpleDateFormat dateAdded;
	private String[] choices = new String[4];
	
	// come back to this. not sure where to place enum
	public enum Categories{
		MATHEMATICS,
		HISTORY,
		GEOGRAPHY,
		SPORTS
	}
	
	public Question(){}
	
	public Question(String name, String category, String addedBy, SimpleDateFormat dateAdded, String[] choices) {
		this.name = name;
		this.category = category;
		this.addedBy = addedBy;
		this.dateAdded = dateAdded;
		this.choices = choices;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}
	
	public String getAddedBy() {
		return addedBy;
	}
	
	public void setAddedBy(String addedBy) {
		this.addedBy = addedBy;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public SimpleDateFormat getDateAdded() {
		return dateAdded;
	}

	public void setDateAdded(SimpleDateFormat dateAdded) {
		this.dateAdded = dateAdded;
	}

	public String[] getChoices() {
		return choices;
	}

	public void setChoices(String[] choices) {
		this.choices = choices;
	}
		
}
