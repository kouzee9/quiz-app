package com.quizapp.view;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

import com.quizapp.model.Question;
import com.quizapp.repo.QuestionRepository;
import com.quizapp.service.QuestionService;

public class Main {

	public static void main(String[] args) {
		QuestionService service;
		QuestionRepository repo;
		final BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
		char[] multipleChoicePrefix = {'A', 'B', 'C', 'D'};
		boolean playAgain = true;
		
		try {
			repo = new QuestionRepository();
			service = new QuestionService(repo);
			
			int i = 0;
			System.out.println("Welcome to Quiz Me! Please select one of the following categories: ");
			System.out.println("Enter 0 to close the program");
			System.out.println();
			
			for (String str : showCategory()) {
				System.out.println(multipleChoicePrefix[i] + ". " + str);
				i++;
			}
			
			String line;
			int score = 0;
			List<String[]> questions;
			EnumMap<Question.Categories, Map<String, String>> answers;
			do {
					System.out.println();	
					line = reader.readLine();
					switch (line.toUpperCase().trim()) {
						case "A":
							System.out.println("You have selected: " + Question.Categories.MATHEMATICS);
							System.out.println();
							System.out.println("Here are a few multiple choice questions on the topics of mathematics.");
							System.out.println();
							
							questions = service.showQuestions(Question.Categories.MATHEMATICS);
							answers = service.showAnswers(Question.Categories.MATHEMATICS);

							String input;
							for (String[] str: questions) {
								
								for (int k = 0; k <= str.length - 1; k++) {
									System.out.println(str[k]);
								}
								
								System.out.println();
								System.out.println("What is the correct answer?");
								
								String questionNumber = str[0].substring(0, 1);
							    String correctAnswer = answers.get(Question.Categories.MATHEMATICS).get(questionNumber);
							    
								input = reader.readLine();
							    System.out.println("Your answer: " + input);
							    System.out.println("Correct answer: " + correctAnswer);

							    if (input.equalsIgnoreCase(correctAnswer)) {
							        score++;
							    }								
							}
							System.out.println("Your total score " + score + "/" + 5);
						break;
						case "B":
							System.out.println("You have selected: " + Question.Categories.HISTORY);
							System.out.println();
							System.out.println("Here are a few multiple choice questions on the topics of history.");
							System.out.println();
							
							questions = service.showQuestions(Question.Categories.HISTORY);
							answers = service.showAnswers(Question.Categories.HISTORY);

							for (String[] str: questions) {
								
								for (int k = 0; k <= str.length - 1; k++) {
									System.out.println(str[k]);
								}
								
								System.out.println();
								System.out.println("What is the correct answer?");
								
								String questionNumber = str[0].substring(0, 1);
							    String correctAnswer = answers.get(Question.Categories.HISTORY).get(questionNumber);
							    
								input = reader.readLine();
							    System.out.println("Your answer: " + input);
							    System.out.println("Correct answer: " + correctAnswer);

							    if (input.equalsIgnoreCase(correctAnswer)) {
							        score++;
							    }								
							}
							System.out.println("Your total score " + score + "/" + 5);
						break;
						case "C":
							System.out.println("You have selected: " + Question.Categories.GEOGRAPHY);
							System.out.println();
							System.out.println("Here are a few multiple choice questions on the topics of geography.");
							System.out.println();
							
							questions = service.showQuestions(Question.Categories.GEOGRAPHY);
							answers = service.showAnswers(Question.Categories.GEOGRAPHY);

							for (String[] str: questions) {
								
								for (int k = 0; k <= str.length - 1; k++) {
									System.out.println(str[k]);
								}
								
								System.out.println();
								System.out.println("What is the correct answer?");
								
								String questionNumber = str[0].substring(0, 1);
							    String correctAnswer = answers.get(Question.Categories.GEOGRAPHY).get(questionNumber);
							    
								input = reader.readLine();
							    System.out.println("Your answer: " + input);
							    System.out.println("Correct answer: " + correctAnswer);

							    if (input.equalsIgnoreCase(correctAnswer)) {
							        score++;
							    }								
							}
							System.out.println("Your total score " + score + "/" + 5);
						break;
						case "D":
							System.out.println("You have selected: " + Question.Categories.SPORTS);
							System.out.println();
							System.out.println("Here are a few multiple choice questions on the topics of geography.");
							System.out.println();
							
							questions = service.showQuestions(Question.Categories.SPORTS);
							answers = service.showAnswers(Question.Categories.SPORTS);

							for (String[] str: questions) {
								
								for (int k = 0; k <= str.length - 1; k++) {
									System.out.println(str[k]);
								}
								
								System.out.println();
								System.out.println("What is the correct answer?");
								
								String questionNumber = str[0].substring(0, 1);
							    String correctAnswer = answers.get(Question.Categories.SPORTS).get(questionNumber);
							    
								input = reader.readLine();
							    System.out.println("Your answer: " + input);
							    System.out.println("Correct answer: " + correctAnswer);

							    if (input.equalsIgnoreCase(correctAnswer)) {
							        score++;
							    }								
							}
							System.out.println("Your total score " + score + "/" + 5);
						break;
						case "0":
							return;
						default:
							System.out.println("Please enter a valid option!");
					}
				System.out.println("Play again? (Y/N)");
				String confirmation = reader.readLine();
				
				if (confirmation.toUpperCase().equals("Y")) {
					playAgain = true;
					System.out.println();
					System.out.println("Welcome to Quiz Me! Please select one of the following categories: ");
					System.out.println("Enter 0 to close the program");
					
					int l = 0;
					for (String str : showCategory()) {
						System.out.println(multipleChoicePrefix[l] + ". " + str);
						l++;
					}
				} else if (confirmation.toUpperCase().equals("N")) {
					playAgain = false;
				} else {
					System.out.println("Invalid option. Goodbye");
					playAgain = false;
				}
				/*
				if (confirmation.toUpperCase().equals("Y")) {
					System.out.println();
					System.out.println("Welcome to Quiz Me! Please select one of the following categories: ");
					System.out.println("Enter 0 to close the program");
					
					int l = 0;
					for (String str : showCategory()) {
						System.out.println(multipleChoicePrefix[l] + ". " + str);
						l++;
					}
					
				} else if (confirmation.toUpperCase().equals("N")) {
					System.out.println("Goodbye!");
					return;
				} else {
					System.out.println("Please enter a valid option!");
				*/
			} while (playAgain);
			
		} catch(IOException io) {
			io.printStackTrace();
		}
		return;
	}
	
	public static String[] showCategory() {
		String[] categories = new String[4];
		int i = 0;
		for (Question.Categories value : Question.Categories.values()) {
			categories[i] = value.toString();
			i++;
		}
		return categories;
	}
}
