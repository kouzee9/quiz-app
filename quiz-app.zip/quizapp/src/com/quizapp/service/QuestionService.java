package com.quizapp.service;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

import com.quizapp.model.Question;
import com.quizapp.repo.QuestionRepository;

public class QuestionService {
	private final QuestionRepository repo;
	
	public QuestionService(QuestionRepository repo) throws FileNotFoundException, IOException {
		this.repo = repo;
	}
	
	public List<String[]> showQuestions(Question.Categories category) throws IOException {
		return repo.retrieveQuestions(category);
	}

	public EnumMap<Question.Categories, Map<String, String>> showAnswers(Question.Categories category) throws IOException {
		return repo.retrieveAnswers(category);
	}
}
